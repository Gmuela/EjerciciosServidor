<?php if ($status) :?>
	<span class="operacionOk">Afición Creada</span>
<?php else :?>
	<span class="operacionFallida">Error al crear la afición</span>
<?php endif;?>

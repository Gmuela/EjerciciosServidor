Utiliza los menús para acceder a las distintas funciones

<nav>
<?= dibujarMenu($menu)?>
</nav>

<header>
	<span class="titulo">Examen MVC</span>
	<div id="usuario"><?= isset($header['usuario'])?'Hola '.$header['usuario']:'No has hecho login' ?></div>
</header>

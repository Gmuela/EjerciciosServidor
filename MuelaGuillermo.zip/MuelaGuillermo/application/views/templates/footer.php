<footer>
	<div id="idFooter">
	<?= isset($d['footer']['mensaje'])?$d['footer']['mensaje']:''?>
	</div>
</footer>

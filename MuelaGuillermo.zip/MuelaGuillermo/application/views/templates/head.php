<!-- En HTML5 no hay DTD asociado -->
<!DOCTYPE html >
<html>
<head>
	<meta charset="utf-8">
	<?= link_tag('assets/css/main.css') ?>
</head>
<body>

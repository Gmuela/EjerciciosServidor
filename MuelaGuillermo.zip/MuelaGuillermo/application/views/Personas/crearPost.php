<?php if ($status) :?>
	<span class="operacionOk">Persona Creada</span>
<?php else :?>
	<span class="operacionFallida">Error al crear la persona</span>
<?php endif;?>
